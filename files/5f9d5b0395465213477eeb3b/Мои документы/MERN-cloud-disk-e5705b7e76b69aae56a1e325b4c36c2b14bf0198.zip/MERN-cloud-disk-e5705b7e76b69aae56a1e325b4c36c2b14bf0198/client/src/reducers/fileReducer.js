
const defaultState = {

}

export default function fileReducer(state = defaultState, action) {
    switch (action.type) {

        default:
            return state
    }
}
